# Documentação de Implementação - Atualização de Comunicação

## 1. Chat Flutuante Unificado
O sistema de chat foi migrado de barras laterais fixas para um modelo flutuante em todos os módulos (`gerenciamento.html`, `motorista.html`, `portaria.html`, `visualizacao.html`).

### Estrutura do Chat:
- **Botão Acionador:** Canto inferior direito.
- **Badge de Notificação:** Um indicador visual vermelho (`!`) é exibido automaticamente via listener do Firebase quando novas mensagens chegam e a janela está fechada.
- **Containers:** O chat é renderizado dinamicamente dentro do ID `#chat-box`.

## 2. Regras de Notificação
- **Módulo Portaria:** Ouve o canal `chat/portaria`.
- **Módulo Admin:** Ouve o canal `chat/admin`.
- **Módulo Motorista:** Ouve o canal `chat/motorista`.
- **Módulo Visualização:** Ouve o canal `chat/global`.

## 3. Fluxo Operacional
O fluxo segue a hierarquia de status:
1. `pendente_validacao` (Iniciando Rota)
2. `aguardando_portaria` (Portaria)
3. `aguardando_descarga` (Pátio)
4. `descarga_em_andamento` (Carregando)
5. `descarga_finalizada` / `liberado` (Concluído)