# EVO Logística - Sistema de Gerenciamento de Fluxo

Sistema robusto para controle de entrada, saída e carregamento de veículos, com foco em segurança e comunicação em tempo real.

## 🚀 Funcionalidades Principais
- **Módulos Específicos:** Admin, Portaria, Motorista e Visualização (Monitor).
- **Validação Fotográfica:** Registro de selfie e placa no início da jornada.
- **Chat em Tempo Real:** Comunicação segmentada por perfil operacional.
- **Dashboard Estatístico:** KPIs de produtividade e ocupação de pátio.

## 🛠️ Tecnologias
- Tailwind CSS
- Firebase Realtime Database
- FontAwesome Icons
- Google Fonts (Inter)